@include('front.header')
@include('front.topnav')

<main class="main">
    @include('front.banner')
    @include('front.about')
    @include('front.why')
    @include('front.menu')
    @include('front.booking')
    @include('front.galeri')
</main>
@include('front.footer')
