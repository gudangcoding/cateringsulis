<!-- About Section -->
<section id="about" class="about section">

    <!-- Section Title -->
    <div class="container section-title" data-aos="fade-up">
        <h2>About Us<br></h2>
        <p><span>Learn More</span> <span class="description-title">About Us</span></p>
    </div><!-- End Section Title -->

    <div class="container">

        <div class="row gy-4">
            <div class="col-lg-7" data-aos="fade-up" data-aos-delay="100">
                <img src="<?php echo e(asset('assets/gambar/PK2.jpeg')); ?>" class="img-fluid mb-4" alt="">
                <div class="book-a-table">
                    <h3>Booking</h3>
                    <a target="_blank" href="https://wa.me/6287788173097" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="WhatsApp">
                        <span class="bi bi-whatsapp me-3"></span>
                        <p>0877 8817 3097</p>
                    </a>
                </div>
            </div>
            <div class="col-lg-5" data-aos="fade-up" data-aos-delay="250">
                <div class="content ps-0 ps-lg-5">
                    <p class="fst-italic">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                        incididunt ut labore et dolore
                        magna aliqua.
                    </p>
                    <ul>
                        <li><i class="bi bi-check-circle-fill"></i> <span>Ullamco laboris nisi ut aliquip ex ea
                                commodo consequat.</span></li>
                        <li><i class="bi bi-check-circle-fill"></i> <span>Duis aute irure dolor in
                                reprehenderit in voluptate velit.</span></li>
                        <li><i class="bi bi-check-circle-fill"></i> <span>Ullamco laboris nisi ut aliquip ex ea
                                commodo consequat. Duis aute irure dolor in reprehenderit in voluptate trideta
                                storacalaperda mastiro dolore eu fugiat nulla pariatur.</span></li>
                    </ul>
                    <p>
                        Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
                        reprehenderit in voluptate
                        velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                        proident
                    </p>

                    <div class="position-relative mt-4">
                        <img src="<?php echo e(asset('assets/gambar/PK3.jpeg')); ?>" class="img-fluid" alt="">

                    </div>
                </div>
            </div>
        </div>

    </div>

</section><!-- /About Section -->
<?php /**PATH C:\laragon\www\cateringsulis\resources\views/front/about.blade.php ENDPATH**/ ?>