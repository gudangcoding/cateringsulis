 <!-- Contact Section -->
 <section id="contact" class="contact section">

     <!-- Section Title -->
     <div class="container section-title" data-aos="fade-up">
         <h2>Contact</h2>
         <p><span>Need Help?</span> <span class="description-title">Contact Us</span></p>
     </div><!-- End Section Title -->

     <div class="container" data-aos="fade-up" data-aos-delay="100">



         <div class="row gy-4">

             <div class="col-md-6">
                 <div class="info-item d-flex align-items-center" data-aos="fade-up" data-aos-delay="200">
                     <i class="icon bi bi-geo-alt flex-shrink-0"></i>
                     <div>
                         <h3>Address</h3>
                         <p>A108 Adam Street, New York, NY 535022</p>
                     </div>
                 </div>
             </div><!-- End Info Item -->

             <div class="col-md-6">
                 <div class="info-item d-flex align-items-center" data-aos="fade-up" data-aos-delay="300">
                     <i class="icon bi bi-telephone flex-shrink-0"></i>
                     <div>
                         <h3>Call Us</h3>
                         <p>+1 5589 55488 55</p>
                     </div>
                 </div>
             </div><!-- End Info Item -->

             <div class="col-md-6">
                 <div class="info-item d-flex align-items-center" data-aos="fade-up" data-aos-delay="400">
                     <i class="icon bi bi-envelope flex-shrink-0"></i>
                     <div>
                         <h3>Email Us</h3>
                         <p>info@example.com</p>
                     </div>
                 </div>
             </div><!-- End Info Item -->

             <div class="col-md-6">
                 <div class="info-item d-flex align-items-center" data-aos="fade-up" data-aos-delay="500">
                     <i class="icon bi bi-clock flex-shrink-0"></i>
                     <div>
                         <h3>Opening Hours<br></h3>
                         <p><strong>Mon-Sat:</strong> 11AM - 23PM; <strong>Sunday:</strong> Closed</p>
                     </div>
                 </div>
             </div><!-- End Info Item -->

         </div>



     </div>

 </section><!-- /Contact Section -->
<?php /**PATH C:\laragon\www\cateringsulis\resources\views/front/kontak.blade.php ENDPATH**/ ?>